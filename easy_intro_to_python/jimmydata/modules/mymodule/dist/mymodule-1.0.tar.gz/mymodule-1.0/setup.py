from setuptools import setup
setup(
    name='mymodule',
    version='1.0',
    description='My very first Python Module!',
    author='Jimmy',
    author_email='jkropp3@uncc.edu',
    py_modules=['mymodule'],
)